<?php

namespace App\Http\Controllers\Admin;
use Mail;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Institute;
use Hash;
use Auth;
use App\PartnerImport;
use Excel;
class PartnerController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $users=User::join('tbl_institute','users.id','=','tbl_institute.institute_id')->select('users.*','tbl_institute.telephone_number','tbl_institute.fax_number','tbl_institute.address_line_1','tbl_institute.address_line_2','tbl_institute.city','tbl_institute.state','tbl_institute.zip','tbl_institute.country')->where('users.role','2')->get();
        return view('admin.partner.index')->with('users',$users);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.partner.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validated =$request->validate([
            'name' => 'required|string',
            'email' => 'required|string|email|max:50|unique:users',
        ]);
        if(!$validated){

            return back()->with('status',$validation->errors());

        }
        $password="Schoolbuddy".date("His").rand(1000,999999);
        $add= new User;
        if($request->hasfile('image'))
        {
            $file=$request->file('image');
            $extension=$file->getClientOriginalExtension();
            $filename=time().'.'.$extension;
            $file->move('admin_assets/upload',$filename);
            $add->image="https://scsy.in/schoolbuddy/schoolbuddy/public/admin_assets/upload/".$filename;
        }
        $add->user_id=Auth::user()->id;
        $add->name=$request->input('name');
        $add->email=$request->input('email');
        $add->mobile_number=$request->input('mobile_number');
        $add->role="2";
        $add->about=$request->input('about_school');
        $add->password=Hash::make($password);
        $add->save();
        
        $add2= new Institute;
        $add2->institute_id=$add->id;
        $add2->telephone_number=$request->input('telephone_number');
        $add2->fax_number=$request->input('fax_number');
        $add2->address_line_1=$request->input('address_line_1');
        $add2->address_line_2=$request->input('address_line_2');
        $add2->city=$request->input('city');
        $add2->state=$request->input('state');
        $add2->zip=$request->input('zip');
        $add2->country=$request->input('country');
        $add2->save();
        
        $data = [
        'email' => $request->input('email'),
        'password' => $password
        ];
        $email = array('email' => $request->input('email'));
        
        Mail::send('admin/mail', $data, function($message) use ($email){
        $message->to($email['email']);
        $message->from('dheeraj@8bittask.com','Uncat');
        });
        
        return back()->with('status','Institute create successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $school=User::join('tbl_institute','users.id','=','tbl_institute.institute_id')->select('users.*','tbl_institute.telephone_number','tbl_institute.fax_number','tbl_institute.address_line_1','tbl_institute.address_line_2','tbl_institute.city','tbl_institute.state','tbl_institute.zip','tbl_institute.country')->where('users.id',$id)->first();
        return view('admin.partner.edit',['school'=>$school]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $add= User::find($id);
        if($request->hasfile('image'))
        {
            $file=$request->file('image');
            $extension=$file->getClientOriginalExtension();
            $filename=time().'.'.$extension;
            $file->move('admin_assets/upload',$filename);
           // dd($filename);
            $add->image="https://scsy.in/schoolbuddy/schoolbuddy/public/admin_assets/upload/".$filename;
        }
        else{
            $add->image=$request->input('oldimage');;
        }
        $add->name=$request->input('name');
        $add->email=$request->input('email');
        $add->mobile_number=$request->input('mobile_number');
        $add->about=$request->input('about_school');
        $add->update();
        
        $add2= Institute::where(['institute_id'=>$id])->first();
        $add2->telephone_number=$request->input('telephone_number');
        $add2->fax_number=$request->input('fax_number');
        $add2->address_line_1=$request->input('address_line_1');
        $add2->address_line_2=$request->input('address_line_2');
        $add2->city=$request->input('city');
        $add2->state=$request->input('state');
        $add2->zip=$request->input('zip');
        $add2->country=$request->input('country');
        $add2->update();
        return back()->with('status','Institute update successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $users=User::findOrFail($id);
        $users->delete();
        
        $partner=Institute::where(['institute_id'=>$id])->first();
        $partner->delete();
        return back()->with('status','Institute Delete successfully');
    }
    
    public function status(Request $request)
    {
        $id=$request->input('id');
        $add= User::find($id);
        $add->login_status=$request->input('status');
        $add->update();
        echo 0;
    }
    
    public function import() 
    {
       $example =  Excel::import(new PartnerImport,request()->file('file'));
       print_r($example); exit;
       return back()->with('status','Partner create successfully');
    }
}
